import time
import telegram

# Apna Telegram Bot Token aur Chat ID yaha daale
BOT_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'
CHAT_ID = 'YOUR_TELEGRAM_CHAT_ID'

# Telegram Bot Setup
bot = telegram.Bot(token=BOT_TOKEN)

# Reminder Messages List
reminders = [
    "🛑 Stop Loss Limit Cross Hone Wala Hai! Game band kar do!",
    "✅ Target Multiplier Achieved! Ab withdraw karo.",
    "⚡️ Safe Multiplier 1.5x tak pahucha. Withdraw karne ka samay hai.",
    "📊 Aaj ki game session me disciplined khelte raho."
]

def send_reminder():
    for message in reminders:
        bot.send_message(chat_id=CHAT_ID, text=message)
        time.sleep(10)  # Har message ke beech 10 second ka delay

if __name__ == '__main__':
    while True:
        send_reminder()
        time.sleep(60 * 30)  # Har 30 minute me reminder bhejo
